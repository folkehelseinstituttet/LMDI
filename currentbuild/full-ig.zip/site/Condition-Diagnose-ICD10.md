# Diagnose-ICD10 - Legemiddeldata fra institusjon til Legemiddelregisteret v1.1.6

* [Hjem](index.md)
* [Informasjonsmodell](informasjonsmodell.md)
* [Integrasjon](integrasjon.md)
* [FHIR-profiler](profiler.md)
* [Nedlastinger](nedlastinger.md)

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Diagnose-ICD10**

## Example Condition: Diagnose-ICD10



## Resource Content

```json
{
  "resourceType" : "Condition",
  "id" : "Diagnose-ICD10",
  "meta" : {
    "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-condition"]
  },
  "clinicalStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
      "code" : "active"
    }]
  },
  "code" : {
    "coding" : [{
      "system" : "urn:oid:2.16.578.1.12.4.1.1.7110",
      "code" : "I20",
      "display" : "Angina pectoris"
    }]
  },
  "subject" : {
    "reference" : "Patient/Pasient-Med-FNR"
  }
}

```
