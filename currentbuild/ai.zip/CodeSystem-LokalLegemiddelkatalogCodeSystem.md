# Lokal Legemiddelkatalog Codes - Legemiddeldata fra institusjon til Legemiddelregisteret v1.1.0

*  [Hjem](index.md) 
*  [Informasjonsmodell](informasjonsmodell.md) 
*  [Integrasjon](integrasjon.md) 
*  [FHIR-profiler](profiler.md) 
*  [Nedlastinger](nedlastinger.md) 

* [Home](en-index.md)
* [Information Model](en-informasjonsmodell.md)
* [Integration](en-integrasjon.md) 
* [Protocol](en-protokoll.md)
* [SignedEncryptedBundle](en-SignertKryptertBundle.md)
* [C# Example Code](en-eksempelkode_cs.md)
* [PowerShell Example Code](en-eksempelkode_ps1.md)
 
* [FHIR Profiles](en-profiler.md)
* [Downloads](en-nedlastinger.md)

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Lokal Legemiddelkatalog Codes**

## CodeSystem: Lokal Legemiddelkatalog Codes 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/ig/lmdi/CodeSystem/LokalLegemiddelkatalogCodeSystem **  | *Version*:1.1.0 **  |
| Active as of 2026-04-30 | *Computable Name*:LokalLegemiddelkatalogCodeSystem |

 
Kodesystem for lokal legemiddelkatalog 

 This Code system is referenced in the content logical definition of the following value sets: 

* [LokalLegemiddelkatalogValues](ValueSet-LokalLegemiddelkatalogValues.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "LokalLegemiddelkatalogCodeSystem",
  "url" : "http://hl7.no/fhir/ig/lmdi/CodeSystem/LokalLegemiddelkatalogCodeSystem",
  "version" : "1.1.0",
  "name" : "LokalLegemiddelkatalogCodeSystem",
  "title" : "Lokal Legemiddelkatalog Codes",
  "status" : "active",
  "date" : "2026-04-30T05:57:00+00:00",
  "publisher" : "Folkehelseinstituttet",
  "contact" : [{
    "name" : "Folkehelseinstituttet",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.fhi.no"
    }]
  },
  {
    "name" : "Legemiddelregisteret",
    "telecom" : [{
      "system" : "email",
      "value" : "legemiddelregisteret@fhi.no"
    }]
  }],
  "description" : "Kodesystem for lokal legemiddelkatalog",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "NO",
      "display" : "Norway"
    }]
  }],
  "content" : "complete",
  "count" : 2,
  "concept" : [{
    "code" : "metavisionkatalogFraHso",
    "display" : "MetavisionkatalogFraHso",
    "definition" : "Metavisionkatalog fra Helse Sør-Øst"
  },
  {
    "code" : "metavisionkatalogFraHN",
    "display" : "MetavisionkatalogFraHN",
    "definition" : "Metavisionkatalog fra Helse Nord"
  }]
}

```
