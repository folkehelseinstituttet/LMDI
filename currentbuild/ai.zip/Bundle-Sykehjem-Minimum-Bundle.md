# Minimumsrapportering fra sykehjem med to administreringer - Legemiddeldata fra institusjon til Legemiddelregisteret v1.0.8

*  [Hjem](index.md) 
*  [Informasjonsmodell](informasjonsmodell.md) 
*  [Integrasjon](integrasjon.md) 
*  [FHIR-profiler](profiler.md) 
*  [Nedlastinger](nedlastinger.md) 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Minimumsrapportering fra sykehjem med to administreringer**

## Example Bundle: Minimumsrapportering fra sykehjem med to administreringer



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Sykehjem-Minimum-Bundle",
  "meta" : {
    "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-bundle"]
  },
  "identifier" : {
    "system" : "urn:oid:2.16.578.1.34.10.3",
    "value" : "sykehjem-minimum-bundle-001"
  },
  "type" : "transaction",
  "timestamp" : "2025-03-10T09:00:00+01:00",
  "entry" : [{
    "resource" : {
      "resourceType" : "Patient",
      "id" : "Sykehjem-Minimum-Pasient",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-patient"]
      },
      "identifier" : [{
        "system" : "urn:oid:2.16.578.1.12.4.1.4.1",
        "value" : "12045678901"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Patient"
    }
  },
  {
    "resource" : {
      "resourceType" : "Organization",
      "id" : "Sykehjem-Minimum-Avdeling",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-organization"]
      },
      "identifier" : [{
        "system" : "urn:oid:2.16.578.1.12.4.1.4.102",
        "value" : "7100001"
      }],
      "name" : "Avdeling 2B, Soltoppen sykehjem",
      "partOf" : {
        "reference" : "Organization/Sykehjem-Minimum-Sykehjem"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Organization"
    }
  },
  {
    "resource" : {
      "resourceType" : "Organization",
      "id" : "Sykehjem-Minimum-Sykehjem",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-organization"]
      },
      "identifier" : [{
        "system" : "urn:oid:2.16.578.1.12.4.1.4.101",
        "value" : "987654321"
      }],
      "name" : "Soltoppen sykehjem",
      "partOf" : {
        "reference" : "Organization/Sykehjem-Minimum-Kommune"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Organization"
    }
  },
  {
    "resource" : {
      "resourceType" : "Organization",
      "id" : "Sykehjem-Minimum-Kommune",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-organization"]
      },
      "identifier" : [{
        "system" : "urn:oid:2.16.578.1.12.4.1.4.101",
        "value" : "938726027"
      }],
      "name" : "Drammen kommune"
    },
    "request" : {
      "method" : "POST",
      "url" : "Organization"
    }
  },
  {
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "Sykehjem-Minimum-Episode",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-encounter"]
      },
      "status" : "in-progress",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "IMP",
        "display" : "inpatient encounter"
      },
      "serviceProvider" : {
        "reference" : "Organization/Sykehjem-Minimum-Avdeling"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Encounter"
    }
  },
  {
    "resource" : {
      "resourceType" : "Medication",
      "id" : "Sykehjem-Minimum-Paracetamol-Merkevare",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-medication"]
      },
      "code" : {
        "coding" : [{
          "system" : "http://dmp.no/fhir/NamingSystem/festLegemiddelMerkevare",
          "code" : "2ABAC272-0BCF-43F0-84BE-984074D92E15",
          "display" : "Paracet tab 500 mg"
        }]
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Medication"
    }
  },
  {
    "resource" : {
      "resourceType" : "Medication",
      "id" : "Sykehjem-Minimum-Oksykodon-Virkestoff",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-medication"]
      },
      "code" : {
        "coding" : [{
          "system" : "http://dmp.no/fhir/NamingSystem/festLegemiddelVirkestoff",
          "code" : "C31AF94A-5D5A-4C91-9B99-BB221E26E4C9",
          "display" : "Oksykodon"
        }]
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Medication"
    }
  },
  {
    "resource" : {
      "resourceType" : "MedicationAdministration",
      "id" : "Sykehjem-Minimum-Administrering-Paracetamol",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-medicationadministration"]
      },
      "status" : "completed",
      "medicationReference" : {
        "reference" : "Medication/Sykehjem-Minimum-Paracetamol-Merkevare"
      },
      "subject" : {
        "reference" : "Patient/Sykehjem-Minimum-Pasient"
      },
      "context" : {
        "reference" : "Encounter/Sykehjem-Minimum-Episode"
      },
      "effectiveDateTime" : "2025-03-10T08:00:00+01:00",
      "dosage" : {
        "dose" : {
          "value" : 500,
          "unit" : "mg",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg"
        }
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationAdministration"
    }
  },
  {
    "resource" : {
      "resourceType" : "MedicationAdministration",
      "id" : "Sykehjem-Minimum-Administrering-Oksykodon",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-medicationadministration"]
      },
      "status" : "completed",
      "medicationReference" : {
        "reference" : "Medication/Sykehjem-Minimum-Oksykodon-Virkestoff"
      },
      "subject" : {
        "reference" : "Patient/Sykehjem-Minimum-Pasient"
      },
      "context" : {
        "reference" : "Encounter/Sykehjem-Minimum-Episode"
      },
      "effectiveDateTime" : "2025-03-10T08:15:00+01:00",
      "dosage" : {
        "dose" : {
          "value" : 5,
          "unit" : "mg",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg"
        }
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationAdministration"
    }
  }]
}

```
