# Lokalt-legemiddel-cellegift - Legemiddeldata fra institusjon til Legemiddelregisteret v1.1.5

* [Hjem](index.md)
* [Informasjonsmodell](informasjonsmodell.md)
* [Integrasjon](integrasjon.md)
* [FHIR-profiler](profiler.md)
* [Nedlastinger](nedlastinger.md)

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Lokalt-legemiddel-cellegift**

## Example Medication: Lokalt-legemiddel-cellegift



## Resource Content

```json
{
  "resourceType" : "Medication",
  "id" : "Lokalt-legemiddel-cellegift",
  "meta" : {
    "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-medication"]
  },
  "extension" : [{
    "url" : "http://hl7.no/fhir/ig/lmdi/StructureDefinition/legemiddel-classification",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://www.whocc.no/atc",
        "code" : "L01XA01",
        "display" : "Cisplatin"
      }]
    }
  }],
  "code" : {
    "coding" : [{
      "system" : "http://fhi.no/fhir/NamingSystem/lokaltLegemiddel",
      "code" : "Cisplatin",
      "display" : "Cisplatin"
    }]
  },
  "amount" : {
    "numerator" : {
      "value" : 1025,
      "unit" : "milligram",
      "system" : "http://unitsofmeasure.org",
      "code" : "mg"
    },
    "denominator" : {
      "value" : 1,
      "unit" : "pose"
    }
  }
}

```
