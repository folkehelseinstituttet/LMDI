# Administrering-1-Oralt - Legemiddeldata fra institusjon til Legemiddelregisteret v1.0.8

*  [Hjem](index.md) 
*  [Informasjonsmodell](informasjonsmodell.md) 
*  [Integrasjon](integrasjon.md) 
*  [FHIR-profiler](profiler.md) 
*  [Nedlastinger](nedlastinger.md) 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Administrering-1-Oralt**

## Example MedicationAdministration: Administrering-1-Oralt



## Resource Content

```json
{
  "resourceType" : "MedicationAdministration",
  "id" : "Administrering-1-Oralt",
  "meta" : {
    "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-medicationadministration"]
  },
  "status" : "completed",
  "medicationReference" : {
    "reference" : "https://fhir.legemidler.example.com/legemidler/123456780"
  },
  "subject" : {
    "reference" : "https://fhi.no/fhir/lmdi/pasient/12345678"
  },
  "context" : {
    "reference" : "https://fhi.no/fhir/lmdi/episode/428ff23d-7a65-4c67-8059-6a1d07d287e3"
  },
  "effectiveDateTime" : "2024-05-28T09:30:00+02:00",
  "dosage" : {
    "route" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "421521009",
        "display" : "Swallow"
      }]
    },
    "dose" : {
      "value" : 10,
      "unit" : "ml",
      "system" : "http://unitsofmeasure.org",
      "code" : "mL"
    }
  }
}

```
