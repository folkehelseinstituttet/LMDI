# Informasjonsmodell - Legemiddeldata fra institusjon til Legemiddelregisteret v1.1.1

* [Hjem](index.md)
* [Informasjonsmodell](informasjonsmodell.md)
* [Integrasjon](integrasjon.md)
* [FHIR-profiler](profiler.md)
* [Nedlastinger](nedlastinger.md)

* [**Table of Contents**](toc.md)
* **Informasjonsmodell**

### Informasjonsmodell - Oversikt

Klikk på klassene for å bli lenket til ressursene

