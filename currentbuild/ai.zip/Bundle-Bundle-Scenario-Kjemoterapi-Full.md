# Fullt kjemoterapiscenario med lokal katalog, forrige rekvirering og aktiv administrering - Legemiddeldata fra institusjon til Legemiddelregisteret v1.0.8

*  [Hjem](index.md) 
*  [Informasjonsmodell](informasjonsmodell.md) 
*  [Integrasjon](integrasjon.md) 
*  [FHIR-profiler](profiler.md) 
*  [Nedlastinger](nedlastinger.md) 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Fullt kjemoterapiscenario med lokal katalog, forrige rekvirering og aktiv administrering**

## Example Bundle: Fullt kjemoterapiscenario med lokal katalog, forrige rekvirering og aktiv administrering



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Bundle-Scenario-Kjemoterapi-Full",
  "meta" : {
    "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-bundle"]
  },
  "identifier" : {
    "system" : "urn:oid:2.16.578.1.34.10.3",
    "value" : "kjemoterapi-full-bundle-001"
  },
  "type" : "transaction",
  "timestamp" : "2025-03-10T12:00:00+01:00",
  "entry" : [{
    "resource" : {
      "resourceType" : "Patient",
      "id" : "Pasient-Scenario-Kjemoterapi-Full-Med-FNR",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-patient"]
      },
      "identifier" : [{
        "system" : "urn:oid:2.16.578.1.12.4.1.4.1",
        "value" : "15076500565"
      }],
      "gender" : "male",
      "birthDate" : "1965-07-15",
      "address" : [{
        "use" : "home",
        "district" : "Trondheim",
        "_district" : {
          "extension" : [{
            "url" : "http://hl7.no/fhir/StructureDefinition/no-basis-municipalitycode",
            "valueCoding" : {
              "system" : "urn:oid:2.16.578.1.12.4.1.1.3402",
              "code" : "5001",
              "display" : "Trondheim"
            }
          }]
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Patient"
    }
  },
  {
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "Helsepersonell-Scenario-Kjemoterapi-Full-Rekvirent",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-practitioner"]
      },
      "identifier" : [{
        "system" : "urn:oid:2.16.578.1.12.4.1.4.4",
        "value" : "8877665"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Practitioner"
    }
  },
  {
    "resource" : {
      "resourceType" : "Organization",
      "id" : "Organisasjon-Scenario-Kjemoterapi-Full-Onkologisk-Avdeling",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-organization"]
      },
      "identifier" : [{
        "system" : "urn:oid:2.16.578.1.12.4.1.4.102",
        "value" : "4201050"
      }],
      "name" : "Onkologisk avdeling, St. Olavs hospital",
      "address" : [{
        "type" : "physical",
        "district" : "Trondheim",
        "_district" : {
          "extension" : [{
            "url" : "http://hl7.no/fhir/StructureDefinition/no-basis-municipalitycode",
            "valueCoding" : {
              "system" : "urn:oid:2.16.578.1.12.4.1.1.3402",
              "code" : "5001",
              "display" : "Trondheim"
            }
          }]
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Organization"
    }
  },
  {
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "Episode-Scenario-Kjemoterapi-Full-Innleggelse",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-encounter"]
      },
      "extension" : [{
        "extension" : [{
          "url" : "stringIdentifier",
          "valueString" : "NPR-STOL-2025-789"
        },
        {
          "url" : "uuidIdentifier",
          "valueUuid" : "9b1deb4d-5b8b-4f83-8f9d-101c6a4a2dd9"
        }],
        "url" : "http://hl7.no/fhir/ig/lmdi/StructureDefinition/npr-episode-identifier"
      }],
      "status" : "in-progress",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "IMP",
        "display" : "inpatient encounter"
      },
      "serviceProvider" : {
        "reference" : "Organization/Organisasjon-Scenario-Kjemoterapi-Full-Onkologisk-Avdeling"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Encounter"
    }
  },
  {
    "resource" : {
      "resourceType" : "Condition",
      "id" : "Diagnose-Scenario-Kjemoterapi-Full-Kreftdiagnose",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-condition"]
      },
      "code" : {
        "coding" : [{
          "system" : "urn:oid:2.16.578.1.12.4.1.1.7110",
          "code" : "C18.7",
          "display" : "Ondartet svulst i sigmoideum"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "363406005",
          "display" : "Malignant tumor of colon"
        }]
      },
      "subject" : {
        "reference" : "Patient/Pasient-Scenario-Kjemoterapi-Full-Med-FNR"
      },
      "stage" : [{
        "summary" : {
          "text" : "Adjuvant kjemoterapi etter colorectal cancer"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Condition"
    }
  },
  {
    "resource" : {
      "resourceType" : "Substance",
      "id" : "Virkestoff-Scenario-Kjemoterapi-Full-Oksaliplatin",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-substance"]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/substance-category",
          "code" : "drug",
          "display" : "Drug or Medicament"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "395814003",
          "display" : "Oxaliplatin (substance)"
        }]
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Substance"
    }
  },
  {
    "resource" : {
      "resourceType" : "Medication",
      "id" : "Legemiddel-Scenario-Kjemoterapi-Full-Oksaliplatin-LokalKatalog",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-medication"]
      },
      "extension" : [{
        "url" : "http://hl7.no/fhir/ig/lmdi/StructureDefinition/legemiddel-classification",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.whocc.no/atc",
            "code" : "L01XA03",
            "display" : "Oksaliplatin"
          }]
        }
      }],
      "code" : {
        "coding" : [{
          "system" : "http://fh.no/fhir/NamingSystem/lokaltVirkemiddel",
          "code" : "OXA-85-INF",
          "display" : "Oksaliplatin 85 mg/m2 infusjonsvæske"
        }]
      },
      "form" : {
        "coding" : [{
          "system" : "urn:oid:2.16.578.1.12.4.1.1.7448",
          "code" : "9",
          "display" : "Infusjonsvæske, oppløsning"
        }]
      },
      "ingredient" : [{
        "itemReference" : {
          "reference" : "Substance/Virkestoff-Scenario-Kjemoterapi-Full-Oksaliplatin"
        },
        "isActive" : true
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Medication"
    }
  },
  {
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "Rekvirering-Scenario-Kjemoterapi-Full-Forrige",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-medicationrequest"]
      },
      "identifier" : [{
        "system" : "http://example.org/rekvirering-id",
        "value" : "KJEMO-2025-001"
      }],
      "status" : "completed",
      "intent" : "order",
      "reportedBoolean" : false,
      "medicationReference" : {
        "reference" : "Medication/Legemiddel-Scenario-Kjemoterapi-Full-Oksaliplatin-LokalKatalog"
      },
      "subject" : {
        "reference" : "Patient/Pasient-Scenario-Kjemoterapi-Full-Med-FNR"
      },
      "encounter" : {
        "reference" : "Encounter/Episode-Scenario-Kjemoterapi-Full-Innleggelse"
      },
      "authoredOn" : "2025-02-24",
      "requester" : {
        "reference" : "Practitioner/Helsepersonell-Scenario-Kjemoterapi-Full-Rekvirent"
      },
      "reasonReference" : [{
        "reference" : "Condition/Diagnose-Scenario-Kjemoterapi-Full-Kreftdiagnose"
      }],
      "courseOfTherapyType" : {
        "text" : "Kjemoterapikur"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationRequest"
    }
  },
  {
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "Rekvirering-Scenario-Kjemoterapi-Full-Gjeldende",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-medicationrequest"]
      },
      "extension" : [{
        "url" : "http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-prosentvis-doseendring",
        "valueQuantity" : {
          "value" : 80,
          "unit" : "%",
          "system" : "http://unitsofmeasure.org",
          "code" : "%"
        }
      },
      {
        "url" : "http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-del-av-behandlingsregime",
        "valueString" : "FOLFOX6"
      },
      {
        "url" : "http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-klinisk-studie",
        "valueBoolean" : true
      }],
      "identifier" : [{
        "system" : "http://example.org/rekvirering-id",
        "value" : "KJEMO-2025-002"
      }],
      "status" : "active",
      "intent" : "order",
      "reportedBoolean" : false,
      "medicationReference" : {
        "reference" : "Medication/Legemiddel-Scenario-Kjemoterapi-Full-Oksaliplatin-LokalKatalog"
      },
      "subject" : {
        "reference" : "Patient/Pasient-Scenario-Kjemoterapi-Full-Med-FNR"
      },
      "encounter" : {
        "reference" : "Encounter/Episode-Scenario-Kjemoterapi-Full-Innleggelse"
      },
      "authoredOn" : "2025-03-10",
      "requester" : {
        "reference" : "Practitioner/Helsepersonell-Scenario-Kjemoterapi-Full-Rekvirent"
      },
      "reasonReference" : [{
        "reference" : "Condition/Diagnose-Scenario-Kjemoterapi-Full-Kreftdiagnose"
      }],
      "courseOfTherapyType" : {
        "text" : "Kjemoterapikur"
      },
      "priorPrescription" : {
        "reference" : "MedicationRequest/Rekvirering-Scenario-Kjemoterapi-Full-Forrige"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationRequest"
    }
  },
  {
    "resource" : {
      "resourceType" : "MedicationAdministration",
      "id" : "Administrering-Scenario-Kjemoterapi-Full-Oksaliplatin",
      "meta" : {
        "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-medicationadministration"]
      },
      "status" : "completed",
      "medicationReference" : {
        "reference" : "Medication/Legemiddel-Scenario-Kjemoterapi-Full-Oksaliplatin-LokalKatalog"
      },
      "subject" : {
        "reference" : "Patient/Pasient-Scenario-Kjemoterapi-Full-Med-FNR"
      },
      "context" : {
        "reference" : "Encounter/Episode-Scenario-Kjemoterapi-Full-Innleggelse"
      },
      "effectivePeriod" : {
        "start" : "2025-03-10T09:00:00+01:00",
        "end" : "2025-03-10T11:00:00+01:00"
      },
      "reasonReference" : [{
        "reference" : "Condition/Diagnose-Scenario-Kjemoterapi-Full-Kreftdiagnose"
      }],
      "request" : {
        "reference" : "MedicationRequest/Rekvirering-Scenario-Kjemoterapi-Full-Gjeldende"
      },
      "dosage" : {
        "route" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "47625008",
            "display" : "Intravenous route (qualifier value)"
          },
          {
            "system" : "urn:oid:2.16.578.1.12.4.1.1.7477",
            "code" : "7",
            "display" : "Intravenøs"
          }]
        },
        "dose" : {
          "value" : 170,
          "unit" : "mg",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg"
        },
        "rateRatio" : {
          "numerator" : {
            "value" : 250,
            "system" : "http://unitsofmeasure.org",
            "code" : "ml"
          },
          "denominator" : {
            "value" : 120,
            "system" : "http://unitsofmeasure.org",
            "code" : "min"
          }
        }
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationAdministration"
    }
  }]
}

```
