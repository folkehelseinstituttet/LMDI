# Legemiddel-Scenario-Smertebehandling-Morfin-Endose - Legemiddeldata fra institusjon til Legemiddelregisteret v1.0.8

*  [Hjem](index.md) 
*  [Informasjonsmodell](informasjonsmodell.md) 
*  [Integrasjon](integrasjon.md) 
*  [FHIR-profiler](profiler.md) 
*  [Nedlastinger](nedlastinger.md) 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Legemiddel-Scenario-Smertebehandling-Morfin-Endose**

## Example Medication: Legemiddel-Scenario-Smertebehandling-Morfin-Endose



## Resource Content

```json
{
  "resourceType" : "Medication",
  "id" : "Legemiddel-Scenario-Smertebehandling-Morfin-Endose",
  "meta" : {
    "profile" : ["http://hl7.no/fhir/ig/lmdi/StructureDefinition/lmdi-medication"]
  },
  "extension" : [{
    "url" : "http://hl7.no/fhir/ig/lmdi/StructureDefinition/legemiddel-classification",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://www.whocc.no/atc",
        "code" : "N02AA01",
        "display" : "Morfin"
      }]
    }
  }],
  "code" : {
    "coding" : [{
      "system" : "http://dmp.no/fhir/NamingSystem/lmrLopenummer",
      "code" : "1234567",
      "display" : "Morfin endose 10 mg/ml"
    },
    {
      "system" : "http://dmp.no/fhir/NamingSystem/fest-varenummer",
      "code" : "476281",
      "display" : "Morfin injeksjonsvæske 10 mg/ml"
    }]
  },
  "form" : {
    "coding" : [{
      "system" : "urn:oid:2.16.578.1.12.4.1.1.7448",
      "code" : "11",
      "display" : "Injeksjonsvæske, oppløsning"
    }]
  }
}

```
