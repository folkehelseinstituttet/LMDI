# hl7.fhir.no.lmdi#1.0.8: Legemiddeldata fra institusjon til Legemiddelregisteret

## Pages

* [Hjem](index.md)
* [FHIR-profiler](profiler.md)
* [Protokoll](protokoll.md)
* [Integrasjon](integrasjon.md)
* [Artifacts Summary](artifacts.md)
* [SignertKryptertBundle](SignertKryptertBundle.md)
* [C# eksempelkode](eksempelkode_cs.md)
* [Powershell eksempelkode](eksempelkode_ps1.md)
* [Informasjonsmodell](informasjonsmodell.md)
* [Nedlastinger](nedlastinger.md)

## Resources

### CodeSystems

* [Lokal Legemiddelkatalog Codes](CodeSystem-LokalLegemiddelkatalogCodeSystem.md)
* [Kommunenummer CodeSystem](CodeSystem-kommunenummer-codesystem.md)

### ValueSets

* [Lokal Legemiddelkatalog Values](ValueSet-LokalLegemiddelkatalogValues.md)
* [ATC Kodesystem ValueSet](ValueSet-atc-valueset.md)
* [Kommunenummer ValueSet](ValueSet-kommunenummer-alle.md)
* [Gyldige legemiddelkoder](ValueSet-legemiddel-koder.md)
* [LMDI Address Type](ValueSet-lmdi-address-type.md)
* [LMDI Address Use](ValueSet-lmdi-address-use.md)
* [Status for legemiddeladministrering](ValueSet-lmdi-medicationadministrationstatus.md)

### Resource Profiles

* [LegemiddelregisterBundle](StructureDefinition-lmdi-bundle.md)
* [Diagnose](StructureDefinition-lmdi-condition.md)
* [Episode](StructureDefinition-lmdi-encounter.md)
* [Legemiddel](StructureDefinition-lmdi-medication.md)
* [Legemiddeladministrering](StructureDefinition-lmdi-medicationadministration.md)
* [Legemiddelrekvirering](StructureDefinition-lmdi-medicationrequest.md)
* [Organisasjon](StructureDefinition-lmdi-organization.md)
* [Pasient](StructureDefinition-lmdi-patient.md)
* [Helsepersonell](StructureDefinition-lmdi-practitioner.md)
* [Virkestoff](StructureDefinition-lmdi-substance.md)

### Extensions

* [Legemiddel Classification](StructureDefinition-legemiddel-classification.md)
* [Del av behandlingsregime](StructureDefinition-lmdi-del-av-behandlingsregime.md)
* [Klinisk studie](StructureDefinition-lmdi-klinisk-studie.md)
* [Prosentvis doseendring](StructureDefinition-lmdi-prosentvis-doseendring.md)
* [NPR Episode Identifier](StructureDefinition-npr-episode-identifier.md)

### ImplementationGuides

* [Legemiddeldata fra institusjon til Legemiddelregisteret](index.md)

### NamingSystems

* [lmdiLokaltLegemiddel](NamingSystem-lmdi-lokaltLegemiddel.md)
* [festLegemiddelDose](NamingSystem-no-basis-fest-legemiddeldose.md)
* [festLegemiddelMerkevare](NamingSystem-no-basis-fest-legemiddelmerkevare.md)
* [festLegemiddelPakning](NamingSystem-no-basis-fest-legemiddelpakning.md)
* [festLegemiddelVirkestoff](NamingSystem-no-basis-fest-legemiddelvirkestoff.md)

### Examples

* [Bundle-Scenario-Kjemoterapi-Full (Bundle)](Bundle-Bundle-Scenario-Kjemoterapi-Full.md)
* [Bundle-Scenario-Smertebehandling (Bundle)](Bundle-Bundle-Scenario-Smertebehandling.md)
* [Bundle-Scenario-Sykehjem-Minimum (Bundle)](Bundle-Bundle-Scenario-Sykehjem-Minimum.md)
* [Bundle-Scenario-Sykehjem-Oksykodon (Bundle)](Bundle-Bundle-Scenario-Sykehjem-Oksykodon.md)
* [Diagnose-Eksempel-ICD10 (Condition)](Condition-Diagnose-Eksempel-ICD10.md)
* [Diagnose-Eksempel-SNOMED-CT (Condition)](Condition-Diagnose-Eksempel-SNOMED-CT.md)
* [Diagnose-Scenario-Kjemoterapi-Full-Kreftdiagnose (Condition)](Condition-Diagnose-Scenario-Kjemoterapi-Full-Kreftdiagnose.md)
* [Diagnose-Scenario-Smertebehandling-Postoperativ-Smerte (Condition)](Condition-Diagnose-Scenario-Smertebehandling-Postoperativ-Smerte.md)
* [Episode-Eksempel-Sykehus (Encounter)](Encounter-Episode-Eksempel-Sykehus.md)
* [Episode-Scenario-Kjemoterapi-Full-Innleggelse (Encounter)](Encounter-Episode-Scenario-Kjemoterapi-Full-Innleggelse.md)
* [Episode-Scenario-Smertebehandling-Innleggelse (Encounter)](Encounter-Episode-Scenario-Smertebehandling-Innleggelse.md)
* [Episode-Scenario-Sykehjem-Minimum-Opphold (Encounter)](Encounter-Episode-Scenario-Sykehjem-Minimum-Opphold.md)
* [Episode-Scenario-Sykehjem-Oksykodon-Opphold (Encounter)](Encounter-Episode-Scenario-Sykehjem-Oksykodon-Opphold.md)
* [Legemiddel-Eksempel-Botox-FEST-Pakning (Medication)](Medication-Legemiddel-Eksempel-Botox-FEST-Pakning.md)
* [Legemiddel-Eksempel-LokalKatalog-Kalsiumklorid-Infusjon (Medication)](Medication-Legemiddel-Eksempel-LokalKatalog-Kalsiumklorid-Infusjon.md)
* [Legemiddel-Eksempel-Monoket-FEST-Pakning (Medication)](Medication-Legemiddel-Eksempel-Monoket-FEST-Pakning.md)
* [Legemiddel-Eksempel-Oksykodon-FEST-Virkestoff (Medication)](Medication-Legemiddel-Eksempel-Oksykodon-FEST-Virkestoff.md)
* [Legemiddel-Eksempel-Paracetamol-FEST-Merkevare (Medication)](Medication-Legemiddel-Eksempel-Paracetamol-FEST-Merkevare.md)
* [Legemiddel-Scenario-Kjemoterapi-Full-Oksaliplatin-LokalKatalog (Medication)](Medication-Legemiddel-Scenario-Kjemoterapi-Full-Oksaliplatin-LokalKatalog.md)
* [Legemiddel-Scenario-Smertebehandling-Morfin-Endose (Medication)](Medication-Legemiddel-Scenario-Smertebehandling-Morfin-Endose.md)
* [Legemiddel-Scenario-Sykehjem-Minimum-Oksykodon-FEST-Virkestoff (Medication)](Medication-Legemiddel-Scenario-Sykehjem-Minimum-Oksykodon-FEST-Virkestoff.md)
* [Legemiddel-Scenario-Sykehjem-Minimum-Paracetamol-FEST-Merkevare (Medication)](Medication-Legemiddel-Scenario-Sykehjem-Minimum-Paracetamol-FEST-Merkevare.md)
* [Legemiddel-Scenario-Sykehjem-Oksykodon-FEST-Dose (Medication)](Medication-Legemiddel-Scenario-Sykehjem-Oksykodon-FEST-Dose.md)
* [Administrering-Eksempel-Botox-Intramuskular (MedicationAdministration)](MedicationAdministration-Administrering-Eksempel-Botox-Intramuskular.md)
* [Administrering-Eksempel-Infusjon (MedicationAdministration)](MedicationAdministration-Administrering-Eksempel-Infusjon.md)
* [Administrering-Eksempel-LogiskReferanse-Infusjon (MedicationAdministration)](MedicationAdministration-Administrering-Eksempel-LogiskReferanse-Infusjon.md)
* [Administrering-Eksempel-Oral (MedicationAdministration)](MedicationAdministration-Administrering-Eksempel-Oral.md)
* [Administrering-Scenario-Kjemoterapi-Full-Oksaliplatin (MedicationAdministration)](MedicationAdministration-Administrering-Scenario-Kjemoterapi-Full-Oksaliplatin.md)
* [Administrering-Scenario-Smertebehandling-Morfin (MedicationAdministration)](MedicationAdministration-Administrering-Scenario-Smertebehandling-Morfin.md)
* [Administrering-Scenario-Sykehjem-Minimum-Oksykodon (MedicationAdministration)](MedicationAdministration-Administrering-Scenario-Sykehjem-Minimum-Oksykodon.md)
* [Administrering-Scenario-Sykehjem-Minimum-Paracetamol (MedicationAdministration)](MedicationAdministration-Administrering-Scenario-Sykehjem-Minimum-Paracetamol.md)
* [Administrering-Scenario-Sykehjem-Oksykodon-Oral (MedicationAdministration)](MedicationAdministration-Administrering-Scenario-Sykehjem-Oksykodon-Oral.md)
* [Rekvirering-Eksempel-Kjemoterapi (MedicationRequest)](MedicationRequest-Rekvirering-Eksempel-Kjemoterapi.md)
* [Rekvirering-Eksempel-Paracetamol (MedicationRequest)](MedicationRequest-Rekvirering-Eksempel-Paracetamol.md)
* [Rekvirering-Scenario-Kjemoterapi-Full-Forrige (MedicationRequest)](MedicationRequest-Rekvirering-Scenario-Kjemoterapi-Full-Forrige.md)
* [Rekvirering-Scenario-Kjemoterapi-Full-Gjeldende (MedicationRequest)](MedicationRequest-Rekvirering-Scenario-Kjemoterapi-Full-Gjeldende.md)
* [Rekvirering-Scenario-Smertebehandling-Morfin (MedicationRequest)](MedicationRequest-Rekvirering-Scenario-Smertebehandling-Morfin.md)
* [Rekvirering-Scenario-Sykehjem-Oksykodon-Oral (MedicationRequest)](MedicationRequest-Rekvirering-Scenario-Sykehjem-Oksykodon-Oral.md)
* [Avdeling for epilepsi, poliklinikk (Organization)](Organization-Organisasjon-Eksempel-Avdeling.md)
* [Lykkedalen sykehjem (Organization)](Organization-Organisasjon-Eksempel-Sykehjem.md)
* [Oslo universitetssykehus HF (Organization)](Organization-Organisasjon-Eksempel-Sykehus.md)
* [Onkologisk avdeling, St. Olavs hospital (Organization)](Organization-Organisasjon-Scenario-Kjemoterapi-Full-Onkologisk-Avdeling.md)
* [Haukeland universitetssjukehus (Organization)](Organization-Organisasjon-Scenario-Smertebehandling-Sykehus.md)
* [Avdeling 2B, Soltoppen sykehjem (Organization)](Organization-Organisasjon-Scenario-Sykehjem-Minimum-Avdeling.md)
* [Drammen kommune (Organization)](Organization-Organisasjon-Scenario-Sykehjem-Minimum-Kommune.md)
* [Soltoppen sykehjem (Organization)](Organization-Organisasjon-Scenario-Sykehjem-Minimum-Sykehjem.md)
* [Lykkedalen eldrehjem (Organization)](Organization-Organisasjon-Scenario-Sykehjem-Oksykodon-Eldrehjem.md)
* [Pasient-Eksempel-Med-FNR (Patient)](Patient-Pasient-Eksempel-Med-FNR.md)
* [Pasient-Eksempel-Uten-FNR (Patient)](Patient-Pasient-Eksempel-Uten-FNR.md)
* [Pasient-Scenario-Kjemoterapi-Full-Med-FNR (Patient)](Patient-Pasient-Scenario-Kjemoterapi-Full-Med-FNR.md)
* [Pasient-Scenario-Smertebehandling-Med-DNR (Patient)](Patient-Pasient-Scenario-Smertebehandling-Med-DNR.md)
* [Pasient-Scenario-Sykehjem-Minimum-Med-FNR (Patient)](Patient-Pasient-Scenario-Sykehjem-Minimum-Med-FNR.md)
* [Pasient-Scenario-Sykehjem-Oksykodon-Med-FNR (Patient)](Patient-Pasient-Scenario-Sykehjem-Oksykodon-Med-FNR.md)
* [Helsepersonell-Eksempel-Med-HPR (Practitioner)](Practitioner-Helsepersonell-Eksempel-Med-HPR.md)
* [Helsepersonell-Eksempel-Uten-HPR (Practitioner)](Practitioner-Helsepersonell-Eksempel-Uten-HPR.md)
* [Helsepersonell-Scenario-Kjemoterapi-Full-Rekvirent (Practitioner)](Practitioner-Helsepersonell-Scenario-Kjemoterapi-Full-Rekvirent.md)
* [Helsepersonell-Scenario-Smertebehandling-Rekvirent (Practitioner)](Practitioner-Helsepersonell-Scenario-Smertebehandling-Rekvirent.md)
* [Helsepersonell-Scenario-Sykehjem-Oksykodon-Rekvirent (Practitioner)](Practitioner-Helsepersonell-Scenario-Sykehjem-Oksykodon-Rekvirent.md)
* [Virkestoff-Eksempel-Oksykodon (Substance)](Substance-Virkestoff-Eksempel-Oksykodon.md)
* [Virkestoff-Scenario-Kjemoterapi-Full-Oksaliplatin (Substance)](Substance-Virkestoff-Scenario-Kjemoterapi-Full-Oksaliplatin.md)
