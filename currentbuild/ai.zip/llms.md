# hl7.fhir.no.lmdi#1.0.8: Legemiddeldata fra institusjon til Legemiddelregisteret

## Pages

* [Hjem](index.md)
* [FHIR-profiler](profiler.md)
* [Protokoll](protokoll.md)
* [Integrasjon](integrasjon.md)
* [Artifacts Summary](artifacts.md)
* [SignertKryptertBundle](SignertKryptertBundle.md)
* [C# eksempelkode](eksempelkode_cs.md)
* [Powershell eksempelkode](eksempelkode_ps1.md)
* [Informasjonsmodell](informasjonsmodell.md)
* [Nedlastinger](nedlastinger.md)

## Resources

### CodeSystems

* [Lokal Legemiddelkatalog Codes](CodeSystem-LokalLegemiddelkatalogCodeSystem.md)
* [Kommunenummer CodeSystem](CodeSystem-kommunenummer-codesystem.md)

### ValueSets

* [Lokal Legemiddelkatalog Values](ValueSet-LokalLegemiddelkatalogValues.md)
* [ATC Kodesystem ValueSet](ValueSet-atc-valueset.md)
* [Kommunenummer ValueSet](ValueSet-kommunenummer-alle.md)
* [Gyldige legemiddelkoder](ValueSet-legemiddel-koder.md)
* [LMDI Address Type](ValueSet-lmdi-address-type.md)
* [LMDI Address Use](ValueSet-lmdi-address-use.md)
* [Status for legemiddeladministrering](ValueSet-lmdi-medicationadministrationstatus.md)

### Resource Profiles

* [LegemiddelregisterBundle](StructureDefinition-lmdi-bundle.md)
* [Diagnose](StructureDefinition-lmdi-condition.md)
* [Episode](StructureDefinition-lmdi-encounter.md)
* [Legemiddel](StructureDefinition-lmdi-medication.md)
* [Legemiddeladministrering](StructureDefinition-lmdi-medicationadministration.md)
* [Legemiddelrekvirering](StructureDefinition-lmdi-medicationrequest.md)
* [Organisasjon](StructureDefinition-lmdi-organization.md)
* [Pasient](StructureDefinition-lmdi-patient.md)
* [Helsepersonell](StructureDefinition-lmdi-practitioner.md)
* [Virkestoff](StructureDefinition-lmdi-substance.md)

### Extensions

* [Legemiddel Classification](StructureDefinition-legemiddel-classification.md)
* [Del av behandlingsregime](StructureDefinition-lmdi-del-av-behandlingsregime.md)
* [Klinisk studie](StructureDefinition-lmdi-klinisk-studie.md)
* [Prosentvis doseendring](StructureDefinition-lmdi-prosentvis-doseendring.md)
* [NPR Episode Identifier](StructureDefinition-npr-episode-identifier.md)

### ImplementationGuides

* [Legemiddeldata fra institusjon til Legemiddelregisteret](index.md)

### NamingSystems

* [lmdiLokaltLegemiddel](NamingSystem-lmdi-lokaltLegemiddel.md)
* [festLegemiddelDose](NamingSystem-no-basis-fest-legemiddeldose.md)
* [festLegemiddelMerkevare](NamingSystem-no-basis-fest-legemiddelmerkevare.md)
* [festLegemiddelPakning](NamingSystem-no-basis-fest-legemiddelpakning.md)
* [festLegemiddelVirkestoff](NamingSystem-no-basis-fest-legemiddelvirkestoff.md)

### Examples

* [Bundle-Contained-Oksykodon-Sykehjem (Bundle)](Bundle-Bundle-Contained-Oksykodon-Sykehjem.md)
* [Endose-Smertebehandling-Bundle (Bundle)](Bundle-Endose-Smertebehandling-Bundle.md)
* [Kjemoterapi-Full-Bundle (Bundle)](Bundle-Kjemoterapi-Full-Bundle.md)
* [Sykehjem-Minimum-Bundle (Bundle)](Bundle-Sykehjem-Minimum-Bundle.md)
* [Diagnose-1-ICD10-OID (Condition)](Condition-Diagnose-1-ICD10-OID.md)
* [Diagnose-2-SNOMED-CT (Condition)](Condition-Diagnose-2-SNOMED-CT.md)
* [Endose-Smertebehandling-Diagnose (Condition)](Condition-Endose-Smertebehandling-Diagnose.md)
* [Kjemoterapi-Full-Diagnose (Condition)](Condition-Kjemoterapi-Full-Diagnose.md)
* [Endose-Smertebehandling-Episode (Encounter)](Encounter-Endose-Smertebehandling-Episode.md)
* [Episode-1-Sykehus (Encounter)](Encounter-Episode-1-Sykehus.md)
* [Kjemoterapi-Full-Episode (Encounter)](Encounter-Kjemoterapi-Full-Episode.md)
* [Sykehjem-Minimum-Episode (Encounter)](Encounter-Sykehjem-Minimum-Episode.md)
* [Endose-Smertebehandling-Morfin-Endose (Medication)](Medication-Endose-Smertebehandling-Morfin-Endose.md)
* [Kjemoterapi-Full-Oksaliplatin-LokalKatalog (Medication)](Medication-Kjemoterapi-Full-Oksaliplatin-LokalKatalog.md)
* [Legemiddel-LokalKatalog-Kalsiumklorid-Infusjon (Medication)](Medication-Legemiddel-LokalKatalog-Kalsiumklorid-Infusjon.md)
* [Medisin-1-LegemiddelDose-Oxycodone (Medication)](Medication-Medisin-1-LegemiddelDose-Oxycodone.md)
* [Medisin-2-Paracetamol (Medication)](Medication-Medisin-2-Paracetamol.md)
* [Medisin-3-LegemiddelPakning-Monoket (Medication)](Medication-Medisin-3-LegemiddelPakning-Monoket.md)
* [Sykehjem-Minimum-Oksykodon-Virkestoff (Medication)](Medication-Sykehjem-Minimum-Oksykodon-Virkestoff.md)
* [Sykehjem-Minimum-Paracetamol-Merkevare (Medication)](Medication-Sykehjem-Minimum-Paracetamol-Merkevare.md)
* [Administrering-1-Oralt (MedicationAdministration)](MedicationAdministration-Administrering-1-Oralt.md)
* [Administrering-2-Infusjon (MedicationAdministration)](MedicationAdministration-Administrering-2-Infusjon.md)
* [Administrering-Contained-Oksykodon-Oral (MedicationAdministration)](MedicationAdministration-Administrering-Contained-Oksykodon-Oral.md)
* [Administrering-LogiskReferanse-Infusjon (MedicationAdministration)](MedicationAdministration-Administrering-LogiskReferanse-Infusjon.md)
* [Administrering-Minimal-Botox-Intramuskular-Contained (MedicationAdministration)](MedicationAdministration-Administrering-Minimal-Botox-Intramuskular-Contained.md)
* [Endose-Smertebehandling-Administrering (MedicationAdministration)](MedicationAdministration-Endose-Smertebehandling-Administrering.md)
* [Kjemoterapi-Full-Administrering (MedicationAdministration)](MedicationAdministration-Kjemoterapi-Full-Administrering.md)
* [Sykehjem-Minimum-Administrering-Oksykodon (MedicationAdministration)](MedicationAdministration-Sykehjem-Minimum-Administrering-Oksykodon.md)
* [Sykehjem-Minimum-Administrering-Paracetamol (MedicationAdministration)](MedicationAdministration-Sykehjem-Minimum-Administrering-Paracetamol.md)
* [Endose-Smertebehandling-Rekvirering (MedicationRequest)](MedicationRequest-Endose-Smertebehandling-Rekvirering.md)
* [Kjemoterapi-Full-Forrige-Rekvirering (MedicationRequest)](MedicationRequest-Kjemoterapi-Full-Forrige-Rekvirering.md)
* [Kjemoterapi-Full-Rekvirering (MedicationRequest)](MedicationRequest-Kjemoterapi-Full-Rekvirering.md)
* [Rekvirering-1 (MedicationRequest)](MedicationRequest-Rekvirering-1.md)
* [Rekvirering-2-Kjemoterapi (MedicationRequest)](MedicationRequest-Rekvirering-2-Kjemoterapi.md)
* [Haukeland universitetssjukehus (Organization)](Organization-Endose-Smertebehandling-Sykehus.md)
* [Onkologisk avdeling, St. Olavs hospital (Organization)](Organization-Kjemoterapi-Full-Organisasjon.md)
* [Lykkedalen sykehjem (Organization)](Organization-Organisasjon-1-Sykehjem.md)
* [Avdeling for epilepsi, poliklinikk (Organization)](Organization-Organisasjon-2-Avdeling.md)
* [Oslo universitetssykehus HF (Organization)](Organization-Organisasjon-3-Sykehus.md)
* [Avdeling 2B, Soltoppen sykehjem (Organization)](Organization-Sykehjem-Minimum-Avdeling.md)
* [Drammen kommune (Organization)](Organization-Sykehjem-Minimum-Kommune.md)
* [Soltoppen sykehjem (Organization)](Organization-Sykehjem-Minimum-Sykehjem.md)
* [Endose-Smertebehandling-Pasient-Dnr (Patient)](Patient-Endose-Smertebehandling-Pasient-Dnr.md)
* [Kjemoterapi-Full-Pasient (Patient)](Patient-Kjemoterapi-Full-Pasient.md)
* [Pasient-1-Uten-FNR (Patient)](Patient-Pasient-1-Uten-FNR.md)
* [Pasient-2-FNR (Patient)](Patient-Pasient-2-FNR.md)
* [Sykehjem-Minimum-Pasient (Patient)](Patient-Sykehjem-Minimum-Pasient.md)
* [Endose-Smertebehandling-Rekvirent (Practitioner)](Practitioner-Endose-Smertebehandling-Rekvirent.md)
* [Helsepersonell-1-HPR-nummer (Practitioner)](Practitioner-Helsepersonell-1-HPR-nummer.md)
* [Helsepersonell-2-Uten-HPR (Practitioner)](Practitioner-Helsepersonell-2-Uten-HPR.md)
* [Kjemoterapi-Full-Helsepersonell (Practitioner)](Practitioner-Kjemoterapi-Full-Helsepersonell.md)
* [Kjemoterapi-Full-Virkestoff (Substance)](Substance-Kjemoterapi-Full-Virkestoff.md)
* [Virkestoff-1-Oksykodon (Substance)](Substance-Virkestoff-1-Oksykodon.md)
