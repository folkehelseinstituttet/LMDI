# hl7.fhir.no.lmdi#1.1.0: Legemiddeldata fra institusjon til Legemiddelregisteret

## Pages

* [Hjem](index.md)
* [Information model](en-informasjonsmodell.md)
* [Home](en-index.md)
* [Protocol](en-protokoll.md)
* [Integration](en-integrasjon.md)
* [Protokoll](protokoll.md)
* [Downloads](en-nedlastinger.md)
* [C# example code](en-eksempelkode_cs.md)
* [Informasjonsmodell](informasjonsmodell.md)
* [FHIR profiles](en-profiler.md)
* [Nedlastinger](nedlastinger.md)
* [C# eksempelkode](eksempelkode_cs.md)
* [FHIR-profiler](profiler.md)
* [Integrasjon](integrasjon.md)
* [PowerShell example code](en-eksempelkode_ps1.md)
* [Artifacts Summary](artifacts.md)
* [Signed and encrypted Bundle](en-SignertKryptertBundle.md)
* [SignertKryptertBundle](SignertKryptertBundle.md)
* [Powershell eksempelkode](eksempelkode_ps1.md)

## Resources

### CodeSystems

* [Lokal Legemiddelkatalog Codes](CodeSystem-LokalLegemiddelkatalogCodeSystem.md)
* [Kommunenummer CodeSystem](CodeSystem-kommunenummer-codesystem.md)

### ValueSets

* [Lokal Legemiddelkatalog Values](ValueSet-LokalLegemiddelkatalogValues.md)
* [ATC Kodesystem ValueSet](ValueSet-atc-valueset.md)
* [Kommunenummer ValueSet](ValueSet-kommunenummer-alle.md)
* [Gyldige legemiddelkoder](ValueSet-legemiddel-koder.md)
* [LMDI Address Type](ValueSet-lmdi-address-type.md)
* [LMDI Address Use](ValueSet-lmdi-address-use.md)
* [Status for legemiddeladministrering](ValueSet-lmdi-medicationadministrationstatus.md)

### Resource Profiles

* [LegemiddelregisterBundle](StructureDefinition-lmdi-bundle.md)
* [Diagnose](StructureDefinition-lmdi-condition.md)
* [Episode](StructureDefinition-lmdi-encounter.md)
* [Legemiddel](StructureDefinition-lmdi-medication.md)
* [Legemiddeladministrering](StructureDefinition-lmdi-medicationadministration.md)
* [Legemiddelrekvirering](StructureDefinition-lmdi-medicationrequest.md)
* [Organisasjon](StructureDefinition-lmdi-organization.md)
* [Pasient](StructureDefinition-lmdi-patient.md)
* [Helsepersonell](StructureDefinition-lmdi-practitioner.md)
* [Virkestoff](StructureDefinition-lmdi-substance.md)

### Extensions

* [Legemiddel Classification](StructureDefinition-legemiddel-classification.md)
* [Del av behandlingsregime](StructureDefinition-lmdi-del-av-behandlingsregime.md)
* [Klinisk studie](StructureDefinition-lmdi-klinisk-studie.md)
* [Prosentvis doseendring](StructureDefinition-lmdi-prosentvis-doseendring.md)
* [NPR Episode Identifier](StructureDefinition-npr-episode-identifier.md)

### ImplementationGuides

* [Legemiddeldata fra institusjon til Legemiddelregisteret](index.md)

### NamingSystems

* [lmdiLokaltLegemiddel](NamingSystem-lmdi-lokaltLegemiddel.md)
* [festLegemiddelDose](NamingSystem-no-basis-fest-legemiddeldose.md)
* [festLegemiddelMerkevare](NamingSystem-no-basis-fest-legemiddelmerkevare.md)
* [festLegemiddelPakning](NamingSystem-no-basis-fest-legemiddelpakning.md)
* [festLegemiddelVirkestoff](NamingSystem-no-basis-fest-legemiddelvirkestoff.md)

### Examples

* [Bundle-Scenario-Sykehjem-Oksykodon (Bundle)](Bundle-Bundle-Scenario-Sykehjem-Oksykodon.md)
* [Diagnose-ICD10-Allergi (Condition)](Condition-Diagnose-ICD10-Allergi.md)
* [Diagnose-ICD10 (Condition)](Condition-Diagnose-ICD10.md)
* [Diagnose-SNOMED-SCT (Condition)](Condition-Diagnose-SNOMED-SCT.md)
* [Episode-Sykehjem (Encounter)](Encounter-Episode-Sykehjem.md)
* [Episode-Sykehus-2 (Encounter)](Encounter-Episode-Sykehus-2.md)
* [Episode-Sykehus (Encounter)](Encounter-Episode-Sykehus.md)
* [Legemiddel-FestLegemiddelMerkevare (Medication)](Medication-Legemiddel-FestLegemiddelMerkevare.md)
* [Legemiddel-FestLegemiddelVirkestoff-2 (Medication)](Medication-Legemiddel-FestLegemiddelVirkestoff-2.md)
* [Legemiddel-FestLegemiddelVirkestoff (Medication)](Medication-Legemiddel-FestLegemiddelVirkestoff.md)
* [Legemiddel-FestLegemiddeldose (Medication)](Medication-Legemiddel-FestLegemiddeldose.md)
* [Legemiddel-FestLegemiddelpakning (Medication)](Medication-Legemiddel-FestLegemiddelpakning.md)
* [Legemiddel-FestLmrLopenr (Medication)](Medication-Legemiddel-FestLmrLopenr.md)
* [Legemiddel-Legemiddeldose-SmofKabiven (Medication)](Medication-Legemiddel-Legemiddeldose-SmofKabiven.md)
* [Legemiddel-LokaltLegemiddel-FlereIngredienser (Medication)](Medication-Legemiddel-LokaltLegemiddel-FlereIngredienser.md)
* [Legemiddel-SCT (Medication)](Medication-Legemiddel-SCT.md)
* [Legemiddel-UtenCoding (Medication)](Medication-Legemiddel-UtenCoding.md)
* [Legemiddel-Varenummer (Medication)](Medication-Legemiddel-Varenummer.md)
* [Lokalt-legemiddel-cellegift (Medication)](Medication-Lokalt-legemiddel-cellegift.md)
* [Administrering-Cellegift (MedicationAdministration)](MedicationAdministration-Administrering-Cellegift.md)
* [Administrering-EnteredInError (MedicationAdministration)](MedicationAdministration-Administrering-EnteredInError.md)
* [Administrering-Infusjon (MedicationAdministration)](MedicationAdministration-Administrering-Infusjon.md)
* [Administrering-MedDiagnoseICD10 (MedicationAdministration)](MedicationAdministration-Administrering-MedDiagnoseICD10.md)
* [Administrering-MedDiagnoseSCT (MedicationAdministration)](MedicationAdministration-Administrering-MedDiagnoseSCT.md)
* [Administrering-Oral (MedicationAdministration)](MedicationAdministration-Administrering-Oral.md)
* [Administrering-Selvadministrert (MedicationAdministration)](MedicationAdministration-Administrering-Selvadministrert.md)
* [Rekvirering-Cellegift (MedicationRequest)](MedicationRequest-Rekvirering-Cellegift.md)
* [Rekvirering-EnteredInError (MedicationRequest)](MedicationRequest-Rekvirering-EnteredInError.md)
* [Rekvirering-Infusjon (MedicationRequest)](MedicationRequest-Rekvirering-Infusjon.md)
* [Rekvirering-Kjemoterapi (MedicationRequest)](MedicationRequest-Rekvirering-Kjemoterapi.md)
* [Rekvirering-MedDiagnoseICD10 (MedicationRequest)](MedicationRequest-Rekvirering-MedDiagnoseICD10.md)
* [Rekvirering-Paracetamol (MedicationRequest)](MedicationRequest-Rekvirering-Paracetamol.md)
* [Helse Møre og Romsdal HF (Organization)](Organization-Organisasjon-HF-2.md)
* [Oslo universitetssykehus HF (Organization)](Organization-Organisasjon-HF.md)
* [TRONDHEIM KOMMUNE (Organization)](Organization-Organisasjon-Kommune.md)
* [HMR ÅLE SH Kreft og blodsjukdommar sengepost (Organization)](Organization-Organisasjon-Post.md)
* [Kreft og blodsykdommer sengepost Ålesund (Organization)](Organization-Organisasjon-Seksjon.md)
* [BYNESET OG NYPANTUNET HELSE- OG VELFERDSSENTER SYKEHJEM (Organization)](Organization-Organisasjon-Sykehjem.md)
* [Helse Møre og Romsdal HF Ålesund sjukehus - Somatikk (Organization)](Organization-Organisasjon-Sykehus-2.md)
* [OSLO UNIVERSITETSSYKEHUS HF SPESIALSYKEHUSET FOR EPILEPSI SSE - SOMATIKK (Organization)](Organization-Organisasjon-Sykehus.md)
* [Avdeling for epilepsi, poliklinikk (Organization)](Organization-Organisasjon-Sykehusavdeling.md)
* [Pasient-Med-DNR (Patient)](Patient-Pasient-Med-DNR.md)
* [Pasient-Med-FNR (Patient)](Patient-Pasient-Med-FNR.md)
* [Pasient-Uten-Personidentifikator (Patient)](Patient-Pasient-Uten-Personidentifikator.md)
* [Helsepersonell-Med-HPR (Practitioner)](Practitioner-Helsepersonell-Med-HPR.md)
* [Helsepersonell-Uten-HPR (Practitioner)](Practitioner-Helsepersonell-Uten-HPR.md)
* [Virkestoff-Oksykodon (Substance)](Substance-Virkestoff-Oksykodon.md)
